# 学生综合信息管理系统原型

课程实验原型，采用 Flask、SQLite 和 Jinja2。支持学生与班级档案、课程选课、成绩、考勤、奖惩、家长联系、模拟通知和按角色授权的工作台。

## 运行条件

在 Windows 上解压整个 ZIP，进入包含 `run.py` 和 `requirements.txt` 的 `StudentManagementSystem` 文件夹，在此打开 PowerShell。验收使用 Python 3.12.10，首次安装依赖需要包源访问。

## 首次安装与初始化

```powershell
py -3.12 --version
py -3.12 -m venv .venv
$prototypePython = Join-Path (Get-Location).Path '.venv\Scripts\python.exe'
& $prototypePython -m pip install -r requirements.txt
& $prototypePython -m pip check
```

以下命令将课堂数据库放在解压目录的 `instance/demo` 下。设置后依次执行迁移、角色初始化和管理员创建。

```powershell
$env:APP_ENV = 'demo'
$env:SMS_INSTANCE_PATH = Join-Path (Get-Location).Path 'instance\demo'
$env:ACTIVE_SEMESTER = '2026-Fall'
$env:DEMO_PORT = '8000'
& $prototypePython -X utf8 -m flask --app run db upgrade
& $prototypePython -X utf8 -m flask --app run db check
& $prototypePython -X utf8 -m flask --app run seed-roles
& $prototypePython -X utf8 -m flask --app run create-admin
& $prototypePython -X utf8 -m flask --app run seed-demo
& $prototypePython -X utf8 run.py
```

`create-admin` 交互输入自选用户名和两次密码，终端隐藏密码。初始化的档案、课程、选课与业务记录均为虚构。该过程需要创建一个可用的管理员，教师和学生的账号由管理员在界面创建。

## 启动和登录

打开 [系统首页](http://127.0.0.1:8000/) 或 [登录页](http://127.0.0.1:8000/login)，使用刚设置的管理员账号登录。健康接口 `/health` 返回 HTTP 200 及包含 `"status": "ok"` 的 JSON。按 Ctrl+C 结束服务。

再次启动时，从解压目录打开 PowerShell，执行下列命令。

```powershell
$prototypePython = Join-Path (Get-Location).Path '.venv\Scripts\python.exe'
$env:APP_ENV = 'demo'
$env:SMS_INSTANCE_PATH = Join-Path (Get-Location).Path 'instance\demo'
$env:ACTIVE_SEMESTER = '2026-Fall'
$env:DEMO_PORT = '8000'
& $prototypePython -X utf8 run.py
```

端口已用时，可以更改 `DEMO_PORT` 并在浏览器打开相同端口。显示 `ModuleNotFoundError` 时，核对命令使用包内 `.venv\Scripts\python.exe`。首次安装未完成时，用同一解释器重新安装 `requirements.txt`。

## 演示三种角色

在管理员的「用户管理」里点击「创建账号」，创建两个自选凭据的演示账号。教师账号选择角色「教师」并绑定 `DEMO-T001 虚构教师甲`，学生账号选择角色「学生」并绑定 `DEMO-S001 虚构学生甲`。完成以后可依次退出并重新登录检查各角色。课程 `DEMO-C001` 已有一条示例选课。演示新增选课时，先建立一个新课程编号。

## 包内文件

- `app/` 包含应用源码、模板与本地静态资源。
- `migrations/` 包含数据库迁移。
- `tests/` 包含 pytest 测试。执行 `& $prototypePython -X utf8 -m pytest -q` 可复核。
- `scripts/sqlite_snapshot.py` 提供 SQLite 快照工具。查看命令帮助可执行 `& $prototypePython -X utf8 scripts/sqlite_snapshot.py --help`。
- `docs/validation/` 保留课程项目原验收结果。
- `manifest.sha256.json` 提供压缩包内文件哈希。

应用在回环地址运行，课堂模式关闭调试器。解压包从空数据库迁移，使用者在本机初始化账号及虚构数据。
